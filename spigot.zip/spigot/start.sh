java -Xms1G -Xmx1G -XX:+UseConcMarkSweepGC -jar ./spigot-1.14.4.jar
